
<!doctype html>
<html lang="tr">
  <head>
    <meta name="robots" content="index, follow" />
    <meta name="keywords" content="emirkan, alma, emirkan alma, web, tasarım, web tasarım" />
    <meta name="description" content="Merhaba ben Emirkan ALMA 18 yaşındayım. Memleketim Sivas fakat İstanbul doğumluyum. Galata Mesleki ve Teknik Anadolu Lisesi'ni Birincilikle bitirdim... " />
    <link rel="apple-touch-icon" sizes="57x57" href="/img/favicon/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/img/favicon/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/img/favicon/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/img/favicon/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/img/favicon/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/img/favicon/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/img/favicon/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/img/favicon/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/img/favicon/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192"  href="/img/favicon/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/img/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="/img/favicon/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/img/favicon/favicon-16x16.png">
    <link rel="manifest" href="/img/favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/img/favicon/ms-icon-144x144.png">
    <meta name="theme-color" content="#ffffff">
    <title>Hoşgeldiniz | Emirkan Alma</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
      rel="stylesheet">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/style.css">
    <script src="js/modernizr.js"></script>
  </head>
  <body data-spy="scroll" data-target=".navbar" data-offset="195">
    <nav class="navbar navbar-expand-lg navbar-light bg-light sps sps--abv">
      <div class="container">
        <a class="navbar-brand scrollToTop" href="javascript:;">
        <img src="img/logo.png" width="50" height="auto" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto ">
            <li class="nav-item">
              <a class="nav-link goSlide" href="#hakkimda">Hakkımda</a>
            </li>
            <li class="nav-item">
              <a class="nav-link goSlide" href="#projelerim">Projeler</a>
            </li>
            <li class="nav-item">
              <a class="nav-link goSlide" href="#iletisim">İletişim</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <div class="hero">
      <div class="emr-bg parallax-window" data-parallax="scroll" data-image-src="https://picsum.photos/g/1920/1280?random">
        <header style="background-color: rgba(0, 0, 0, 0.4);">
          <section class="header-content">
            <h1 class="header-title animate-pop-in">İnsan diliyle değil, </h1>
            <h3 class="header-subtitle animate-pop-in">yaptığı işlerle konuşmalı</h3>
          </section>
          <div class="animate-pop-in" style="position: absolute;bottom: 100px;"><a href="#hakkimda" class="wow bounceInUp goSlide" style="color:#4ebcc2;font-size: 40px;"><i class="fas fa-chevron-down"></i></a></div>
        </header>
      </div>
    </div>
    <div id="hakkimda" class="section gutter ">
      <div class="emr-hakkimda">
        <div class="container">
          <div class="row">
            <div class="col-md-12 col-lg-6  d-flex" style="align-items:center;">
              <div>
                <h2 style="    margin-top: 35px;">Hakkımda</h2>
                <i class="glyphicon glyphicon-eur"></i>
                <p>Merhaba ben Emirkan ALMA 18 yaşındayım. Memleketim Sivas fakat İstanbul doğumluyum. Galata Mesleki ve Teknik Anadolu Lisesi'ni Birincilikle bitirdim. Web Tasarımı ve Programlama konularında kendimi geliştirdim ve geliştirmeye devam ediyorum. Üniversite hedefim de Bilgisayar Mühendisliği okumaktır. Şuan <a href="http://www.maama.me" target="_blank">Maama Marketing Innovations</a>'da çalışmaktayım. Devamı Gelecek...</p>
              </div>
            </div>
            <div class="col-md-12 col-lg-6 text-center">
              <img src="img/emirkanalma.jpg" width="500"class="img-fluid lazyload hakkimda-img wow bounceInUp" alt="">
            </div>
          </div>
        </div>
      </div>
    </div>
    <div id="projelerim" class="section section-dark">
      <div class="emr-projelerim">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12 text-center">
              <h1 style="padding:30px 0 40px">Projelerim</h1>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <div class="owl-carousel owl-theme owl-proje">

                <div class="tilt-item">
                  <a href="https://www.spiralsan.com" target="_blank">
                    <div data-tilt class="js-tilt" style="transform-style: preserve-3d">
                      <img src="img/proje1.png" alt="" width="100">
                      <div class="tilt-yazi">Spiralsan</div>
                    </div>
                  </a>
                </div>
                <div class="tilt-item">
                  <a href="javascript:;">
                    <div data-tilt class="js-tilt" style="transform-style: preserve-3d">
                      <img src="img/proje.png" alt="" width="100">
                      <div class="tilt-yazi">Eklenmedi</div>
                    </div>
                  </a>
                </div>
                <div class="tilt-item">
                  <a href="javascript:;">
                    <div data-tilt class="js-tilt" style="transform-style: preserve-3d">
                      <img src="img/proje.png" alt="" width="100">
                      <div class="tilt-yazi">Eklenmedi</div>
                    </div>
                  </a>
                </div>
                <div class="tilt-item">
                  <a href="javascript:;">
                    <div data-tilt class="js-tilt" style="transform-style: preserve-3d">
                      <img src="img/proje.png" alt="" width="100">
                      <div class="tilt-yazi">Eklenmedi</div>
                    </div>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div id="iletisim" class="section gutter ">
      <div class="emr-iletisim">
        <div class="container">
          <div class="row">
            <div class="col-md-12 emr-iletisim2" style="">
              <section id="hire">
                <h1>İletişim</h1>
                <form id="emr-form" name="iletisimform" role="form"  method="post" action="mail_gonder.php">
                  <div class="field name-box form-group">
                    <input type="text" id="name" name="isimsoyisim" placeholder="Adın ve Soyadın" class="form-control" required/>
                    <label for="name">İsim</label>
                    <span class="ss-icon">
                      <svg id="i-checkmark" viewBox="0 0 32 32" width="32" height="32" fill="none" stroke="currentcolor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2">
                        <path d="M2 20 L12 28 30 4" />
                      </svg>
                    </span>
                  </div>
                  <div class="field tel-box form-group">
                    <input type="text" id="telefon" name="telefon" placeholder="Telefon Numaran" class="form-control" required/>
                    <label for="telefon">Tel</label>
                    <span class="ss-icon">
                      <svg id="i-checkmark" viewBox="0 0 32 32" width="32" height="32" fill="none" stroke="currentcolor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2">
                        <path d="M2 20 L12 28 30 4" />
                      </svg>
                    </span>
                  </div>
                  <div class="field email-box form-group">
                    <input type="text" id="email" name="email" placeholder="örnek@email.com" class="form-control" required/>
                    <label for="email">Email</label>
                    <span class="ss-icon">
                      <svg id="i-checkmark" viewBox="0 0 32 32" width="32" height="32" fill="none" stroke="currentcolor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2">
                        <path d="M2 20 L12 28 30 4" />
                      </svg>
                    </span>
                  </div>
                  <div class="field msg-box form-group">
                    <textarea id="msg" name="mesaj" rows="4" placeholder="Lütfen mesajını buraya yaz..." class="form-control" required/></textarea>
                    <label for="msg">Msj</label>
                    <span class="ss-icon">
                      <svg id="i-checkmark" viewBox="0 0 32 32" width="32" height="32" fill="none" stroke="currentcolor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2">
                        <path d="M2 20 L12 28 30 4" />
                      </svg>
                    </span>
                  </div>
                  <!-- <div class="g-recaptcha" data-sitekey="6LdSAVwUAAAAAPYHwC2RhGgRAlNtEvevCJIoLFGu"></div> -->
                  <input class="button" type="submit" value="Gönder" id="emr-gonder"  style="margin-top:5px;" />
                </form>
              </section>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- <div id="instagram" class="section" style="line-height:0;" >
      <script src="https://cdn.lightwidget.com/widgets/lightwidget.js"></script><iframe src="//lightwidget.com/widgets/d8d881d6e7fb5d2ab82c436b85fc8549.html" scrolling="no" allowtransparency="true" class="lightwidget-widget" style="width:100%;border:0;overflow:hidden;"></iframe>
    </div> -->
    <footer class="page-footer font-small cyan darken-3 mt-4">

      <div class="container">

        <div class="row">

          <div class="col-md-12 py-5">
            <div class="d-flex flex-center" style="justify-content:center;align-items:center;">

              <a href="https://www.facebook.com/emirkanalma" class="social-icons fb-ic" target="_blank">
                <i class="fab fa-facebook fa-lg white-text mr-3 fa-2x"> </i>
              </a>
              <a href="https://www.instagram.com/emirkanalma/" class="social-icons ins-ic" target="_blank">
                <i class="fab fa-instagram fa-lg white-text  mr-3 fa-2x"> </i>
              </a>
              <a href="https://twitter.com/emirkanalma/" class="social-icons tw-ic" target="_blank">
                <i class="fab fa-twitter fa-lg white-text  mr-3 fa-2x"> </i>
              </a>
              <a href="https://www.linkedin.com/in/emirkan-alma-25204a149/" class="social-icons li-ic" target="_blank">
                <i class="fab fa-linkedin fa-lg white-text  mr-3 fa-2x"> </i>
              </a>
            </div>
          </div>

        </div>

      </div>

      <div class="footer-copyright text-center py-3">© 2018 Copyright:
        <a href="https://www.emirkanalma.com"> emirkanalma.com</a>
      </div>
    </footer>

    <a href="javascript:;" class="scrollToTop topbutton"><i class="fas fa-chevron-circle-up"></i></a>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.7/js/all.js"></script>
    <script src='https://www.google.com/recaptcha/api.js'></script>
    <script src='https://unpkg.com/sweetalert2@7.21.1/dist/sweetalert2.all.js'></script>
    <script src="js/lazysizes.min.js" async=""></script>
    <script src="js/ls.bgset.min.js" async=""></script>
    <script src="js/scrollPosStyler.min.js" async=""></script>
    <script src="js/parallax.min.js" async=""></script>
    <script src="js/tilt.jquery.js" async=""></script>
    <script type="text/javascript" src="js/owl.carousel.min.js"></script>
    <script type="text/javascript" src="js/wow.min.js"></script>
    <!-- <script type="text/javascript" src="js/skrollr.min.js"></script>
    <script type="text/javascript">
  	  var s = skrollr.init({forceHeight: false});
  	</script> -->
    <script src="js/main.js"></script>
    <script type="text/javascript">
  	  new WOW().init();
  	</script>
    <?php
    // function GetIP(){
    //  if(getenv("HTTP_CLIENT_IP")) {
    //  $ip = getenv("HTTP_CLIENT_IP");
    //  } elseif(getenv("HTTP_X_FORWARDED_FOR")) {
    //  $ip = getenv("HTTP_X_FORWARDED_FOR");
    //  if (strstr($ip, ',')) {
    //  $tmp = explode (',', $ip);
    //  $ip = trim($tmp[0]);
    //  }
    //  } else {
    //  $ip = getenv("REMOTE_ADDR");
    //  }
    //  return $ip;
    // }
    // $ip_adresi = GetIP();
    //
    // require("class.phpmailer.php");
    // $mail = new PHPMailer(); // create a new object
    // $mail->IsSMTP(); // enable SMTP
    // $mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
    // $mail->SMTPAuth = true; // authentication enabled
    // $mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for GMail
    // $mail->Host = "mail.emirkanalma.com";
    // $mail->Port = 465; // or 587
    // $mail->IsHTML(true);
    // $mail->SetLanguage("tr", "phpmailer/language");
    // $mail->CharSet  ="utf-8";
    //
    // $mail->Username = "iletisim@emirkanalma.com"; // Mail adresi
    // $mail->Password = "147896325Emr"; // Parola
    // $mail->SetFrom("iletisim@emirkanalma.com", "EmirkanAlma.com"); // Mail adresi
    //
    // $mail->AddAddress("emirkan@maama.me"); // Gönderilecek kişi
    //
    // $mail->Subject = "SAYFAYA BİRİ GİRDİ";
    // $mail->Body = "İP ADRESİ: $ip_adresi";
    //
    // if(!$mail->Send()){
    //
    // } else {
    //
    // }
    //

    ?>
  </body>
</html>
