
      $('.owl-proje').owlCarousel({
          loop:false,
          margin:10,
          nav:true,
          navText:['<i class="fas fa-chevron-left"></i>','<i class="fas fa-chevron-right"></i>'],
          responsive:{
              0:{
                  items:1
              },
              768:{
                  items:2
              },
              1200:{
                  items:3
              }
          }
      });

      $('.owl-main').owlCarousel({
        loop:true,
        margin:10,
        nav:true,
        responsive:{
            0:{
                items:1
            },
            600:{
                items:3
            },
            1000:{
                items:5
            }
        }
      });

      $(".goSlide").on("click", function(e){
        e.preventDefault();
          var dest = $(this).attr("href");
          $('html, body').animate({
              scrollTop: $(dest).offset().top -168
          }, 800);
      });





			$(document).ready(function(){
					$(window).scroll(function(){
							if ($(this).scrollTop() > 500) {
									$('.topbutton').fadeIn();
							} else {
									$('.topbutton').fadeOut();
							}
					});
					$('.scrollToTop').click(function(e){
							e.preventDefault();
							$('html, body').animate({scrollTop : 0},800);
							return false;
					});
			});




			$('textarea').blur(function () {
      $('#hire textarea').each(function () {
        $this = $(this);
        if ( this.value != '' ) {
          $this.addClass('focused');
          $('textarea + label + span').css({'opacity': 1});
        }
        else {
          $this.removeClass('focused');
          $('textarea + label + span').css({'opacity': 0});
        }
      });
      });

      $('#hire .field:first-child input').blur(function () {
      $('#hire .field:first-child input').each(function () {
        $this = $(this);
        if ( this.value != '' ) {
          $this.addClass('focused');
          $('.field:first-child input + label + span').css({'opacity': 1});
        }
        else {
          $this.removeClass('focused');
          $('.field:first-child input + label + span').css({'opacity': 0});
        }
      });
      });

      $('#hire .field:nth-child(2) input').blur(function () {
      $('#hire .field:nth-child(2) input').each(function () {
        $this = $(this);
        if ( this.value != '' ) {
          $this.addClass('focused');
          $('.field:nth-child(2) input + label + span').css({'opacity': 1});
        }
        else {
          $this.removeClass('focused');
          $('.field:nth-child(2) input + label + span').css({'opacity': 0});
        }
      });
      });
      $('#hire .field:nth-child(3) input').blur(function () {
      $('#hire .field:nth-child(3) input').each(function () {
        $this = $(this);
        if ( this.value != '' ) {
          $this.addClass('focused');
          $('.field:nth-child(3) input + label + span').css({'opacity': 1});
        }
        else {
          $this.removeClass('focused');
          $('.field:nth-child(3) input + label + span').css({'opacity': 0});
        }
      });
      });
      // swal({
      //   title: '<i>Hoşgeldiniz</i>',
      //   type: 'info',
      //   html:
      //     'Sayfamın Yapım Aşaması Devam Etmekdedir.',
      //   showCloseButton: true,
      //   showCancelButton: true,
      //   focusConfirm: false,
      //   confirmButtonText:
      //     '<i class="fa fa-thumbs-up"></i> Tamam',
      //   confirmButtonAriaLabel: 'Thumbs up, great!',
      //   cancelButtonText:
      //   '<i class="fab fa-instagram"></i> Instagram',
      //   cancelButtonAriaLabel: 'great',
      // }).then((result) => {
      //    if (
      //     result.dismiss === swal.DismissReason.cancel
      //   ) {
      //     window.location.href = "http://instagram.com/emirkanalma"
      //   }
      // });

      $("#emr-form").submit(function(e) {
        var url = "mail_gonder.php"; // the script where you handle the form input.

        $.ajax({
               type: "POST",
               url: url,
               data: $("#emr-form").serialize(), // serializes the form's elements.
               success: function(data)
               {
                   alert(data);
                   $("#name").val("").removeClass("focused");
                   $("#telefon").val("").removeClass("focused");
                   $("#email").val("").removeClass("focused");
                   $("#msg").val("").removeClass("focused");
                   $(".ss-icon").css("opacity", "0")
               }
             });

        e.preventDefault(); // avoid to execute the actual submit of the form.
    });


        // var v = grecaptcha.getResponse();
        // if(v.length == 0)
        // {
        //     document.getElementById('captcha').innerHTML="You can't leave Captcha Code empty";
        //     $("#emr-form").submit(function(e){e.preventDefault();});
        //     return false;
        // }
        // else
        // {
        //     document.getElementById('captcha').innerHTML="Captcha completed";
        //     $("#emr-form").submit();
        //     return true;
        // }

      // $("#emr-gonder").on("click", function() {
      //     });
