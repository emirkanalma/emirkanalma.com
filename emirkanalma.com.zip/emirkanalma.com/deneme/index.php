<form id="form1" name="form1" method="post" action="mail_gonder.php">
<table width="455" border="1">
<tr>
<td width="242"><div align="right">Adiniz Soyadiniz :</div></td>
<td width="197">
<label>
<input type="text" name="name" id="textfield" />
</label> </td>
</tr>
<tr>
<td><div align="right">E-posta adresiniz:</div></td>
<td>
<label>
<input type="text" name="email" id="textfield2" />
</label> </td>
</tr>
<tr>
<td><div align="right">Konu:</div></td>
<td>
<label>
<input type="text" name="subject" id="textfield3" />
</label> </td>
</tr>
<tr>
<td><div align="right">Mesaj:</div></td>
<td><label>
<textarea name="message" cols="30" rows="5"></textarea>
</label></td>
</tr>
<tr>
<td><div align="right"></div></td>
<td><label>
<input type="submit" name="button" id="button" value="Gönder " />
</label></td>
</tr>
</table>
</form>
