<html><head><meta http-*****="Content-Type" **********text/html; charset=windows-1254"></head><body>
<?php
$to = "msn adresini buraya yaz";
$subject = "Iletisim Formu";


$headers = "From:" . $_POST["isim"];
$headers .= "<" . $_POST["eposta"] . ">\r\n";
$headers .= "Reply-To: " . $_POST["eposta"] . "\r\n";
$headers .= "Return-Path: " . $_POST["eposta"];

$message .= "Sitenizden gelen iletisim form islem sonucu\n\n";
$message .= "Adi soyadi: " . $_POST["isim"] . "\r\n";
$message .= "Email: " . $_POST["eposta"] . "\r\n";
$message .= "Konu: " . $_POST["konu"] . "\r\n";
$message .= "mesaj: " . $_POST["mesaj"] . "\r\n";

$mail_kontrol=mail($to, $subject, $message, $headers);

if ($mail_kontrol) {echo "Yollama başarılı";}
else {echo "Mesaj Yollama hatası";}
?>

</body>
