<?php
function GetIP(){
 if(getenv("HTTP_CLIENT_IP")) {
 $ip = getenv("HTTP_CLIENT_IP");
 } elseif(getenv("HTTP_X_FORWARDED_FOR")) {
 $ip = getenv("HTTP_X_FORWARDED_FOR");
 if (strstr($ip, ',')) {
 $tmp = explode (',', $ip);
 $ip = trim($tmp[0]);
 }
 } else {
 $ip = getenv("REMOTE_ADDR");
 }
 return $ip;
}
$ip_adresi = GetIP();

$name = $_POST["isimsoyisim"];
$email = $_POST["email"];
$telefon = $_POST["telefon"];
$message = $_POST["mesaj"];
require("class.phpmailer.php");
$mail = new PHPMailer(); // create a new object
$mail->IsSMTP(); // enable SMTP
$mail->SMTPDebug = 1; // debugging: 1 = errors and messages, 2 = messages only
$mail->SMTPAuth = true; // authentication enabled
$mail->SMTPSecure = 'ssl'; // secure transfer enabled REQUIRED for GMail
$mail->Host = "mail.emirkanalma.com";
$mail->Port = 465; // or 587
$mail->IsHTML(true);
$mail->SetLanguage("tr", "phpmailer/language");
$mail->CharSet  ="utf-8";

$mail->Username = "iletisim@emirkanalma.com"; // Mail adresi
$mail->Password = "147896325Emr"; // Parola
$mail->SetFrom("iletisim@emirkanalma.com", "EmirkanAlma.com"); // Mail adresi

$mail->AddAddress("emirkan@maama.me"); // Gönderilecek kişi

$mail->Subject = "SAYFADAN MESAJ VAR";
$mail->Body = "MESAJI GÖNDEREN: $name <br />MAİL ADERSİ: $email <br />TELEFON NUMARASI: $telefon<br />MESAJI: $message<br/>İP ADRESİ: $ip_adresi";

if(!$mail->Send()){
        echo "Mail Gönderilirken Bir Hatayla Karşılaştık:".$mail->ErrorInfo;
} else {
        echo "Mesajınız Başarıyla Gönderildi. Teşekkür Ederim.";
}


?>
